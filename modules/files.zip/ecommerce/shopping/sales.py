from ecommerce.customer import contact  # absolute import
from ..customer import contact


def cal_tax():
    pass


def cal_shipping():
    print("Shipping!")
